package es.ieslavereda.helloworld;

public enum  Operador {
    SUMA, RESTA, MULTIPLICACION, DIVISION
}
